package controller;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import controller.user.*;
import controller.client.*;
import controller.ceo.*;

public class RequestMapping {
    private static final Logger logger = LoggerFactory.getLogger(DispatcherServlet.class);
    
    // �� ��û uri�� ���� controller ��ü�� ������ HashMap ����
    private Map<String, Controller> mappings = new HashMap<String, Controller>();

    public void initMapping() {
    	// �� uri�� �����Ǵ� controller ��ü�� ���� �� ����
    	mappings.put("/", new ForwardController("index.jsp"));
        mappings.put("/user/login/form", new ForwardController("/user/loginForm.jsp"));
        mappings.put("/user/login", new LoginController());
        mappings.put("/user/logout", new LogoutController());
        mappings.put("/client/register/form", new ForwardController("/client/clientRegisterForm.jsp"));
        mappings.put("/ceo/register/form", new ForwardController("/ceo/ceoRegisterForm.jsp"));
        mappings.put("/client/main", new ListClientController());
        mappings.put("/ceo/main", new ListCeoController());
        mappings.put("/client/cafe", new ClientToCafeController());
        mappings.put("/client/order/form", new ForwardController("/client/clientOrderForm.jsp"));
        mappings.put("/ceo/menu", new ListCeoMenuController());
        mappings.put("/ceo/menu/list", new ForwardController("/ceo/ceoMenuList.jsp"));
        mappings.put("/ceo/menu/update", new UpdateMenuController());
        //�̺κ� �߰��ؾ���. 
        //mappings.put("/ceo/menu/add", new AddMenuController());
        //mappings.put("/ceo/menu/addForm", new ForwardController("/ceo/ceoMenuAddForm.jsp"));
        //mappings.put("/ceo/menu/delete", new DeleteMenuController());
        mappings.put("/ceo/menu/form", new ForwardController("/ceo/ceoMenuForm.jsp"));
        mappings.put("/ceo/store", new FormCeoStoreController());
        mappings.put("/ceo/store/form", new ForwardController("/ceo/ceoStoreForm.jsp"));
        mappings.put("/client/", new RegisterClientController());
        mappings.put("/ceo/register", new RegisterCeoController());
        
        logger.info("Initialized Request Mapping!");
    }

    public Controller findController(String uri) {	
    	// �־��� uri�� �����Ǵ� controller ��ü�� ã�� ��ȯ
        return mappings.get(uri);
    }
}
