package controller.client;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Controller;
import controller.user.UserSessionUtils;


public class ClientToCafeController implements Controller {
	 public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
			// �α��� ���� Ȯ��
	    	if (!UserSessionUtils.hasLogined(request.getSession())) {
	            return "redirect:/user/login/form";		// login form ��û���� redirect
	        }
	    	
	    /* ���� cafe �����ȵż� �ּ�ó��
	     * CafeManager manager = CafeManager.getInstance();
			int CafeCode = (Integer)request.getAttribute(cafeCode);
			Cafe cafe = manager.findCafe(cafeCode);
			
			request.setAttribute("cafe", cafe);
*/
			return "/client/order/form"; 
	 }
}
