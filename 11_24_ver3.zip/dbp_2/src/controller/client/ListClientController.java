package controller.client;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import controller.Controller;
import controller.user.UserSessionUtils;
import model.Client;
import model.service.ClientManager;

public class ListClientController implements Controller {
	// private static final int countPerPage = 100;	// �� ȭ�鿡 ����� ����� ��

    @Override
    public String execute(HttpServletRequest request, HttpServletResponse response)	throws Exception {
		// �α��� ���� Ȯ��
    	if (!UserSessionUtils.hasLogined(request.getSession())) {
            return "redirect:/user/login/form";		// login form ��û���� redirect
        }
    	
    	/*
    	String currentPageStr = request.getParameter("currentPage");	
		int currentPage = 1;
		if (currentPageStr != null && !currentPageStr.equals("")) {
			currentPage = Integer.parseInt(currentPageStr);
		}		
    	*/
    	
		ClientManager manager = ClientManager.getInstance();
		List<Client> clientList = manager.findUserList();
		// List<User> userList = manager.findUserList(currentPage, countPerPage);

		// userList ��ü�� ���� �α����� ����� ID�� request�� �����Ͽ� ����
		request.setAttribute("userList", clientList);
		String curUser = UserSessionUtils.getLoginUserId(request.getSession());
		request.setAttribute("curUserId", 
				curUser);
		Client client = manager.findUser(curUser);
		String gu = client.getAddrgu();
		String dong = client.getAddrdong();
		request.setAttribute("curUserGu", 
				gu);
		request.setAttribute("curUserDong", 
				dong);

		// ����� ����Ʈ ȭ������ �̵�(forwarding)
		return "/client/clientMain.jsp";        
    }
}
