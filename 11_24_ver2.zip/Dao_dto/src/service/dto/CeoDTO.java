package service.dto;

public class CeoDTO {
	private String ceoId;			//���� ���̵�
	private String ceoName;			//���� �̸�
	private String ceoPasswd;		//���� ��й�ȣ
	private String ceoPhone;		//���� �ڵ�����ȣ
	private String registrationNum;	//����ڵ�Ϲ�ȣ
	
	public String getCeoId() {
		return ceoId;
	}
	public void setCeoId(String ceoId) {
		this.ceoId = ceoId;
	}
	public String getCeoName() {
		return ceoName;
	}
	public void setCeoName(String ceoName) {
		this.ceoName = ceoName;
	}
	public String getCeoPasswd() {
		return ceoPasswd;
	}
	public void setCeoPasswd(String ceoPasswd) {
		this.ceoPasswd = ceoPasswd;
	}
	public String getCeoPhone() {
		return ceoPhone;
	}
	public void setCeoPhone(String ceoPhone) {
		this.ceoPhone = ceoPhone;
	}
	public String getRegistrationNum() {
		return registrationNum;
	}
	public void setRegistrationNum(String registrationNum) {
		this.registrationNum = registrationNum;
	}
	
	
}
